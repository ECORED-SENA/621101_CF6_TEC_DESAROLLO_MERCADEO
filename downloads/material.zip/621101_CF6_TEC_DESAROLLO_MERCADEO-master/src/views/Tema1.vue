<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5
    .titulo-principal
      .titulo-principal__numero
        span 1
      h1 Merchandising
    .row
      .col-10.offset-1

        .bloque-texto-a.color-secundario.p-4.p-md-5.mb-5 
          .row.m-0.align-items-center.justify-content-between
            .col-lg-4.mb-4.mb-lg-.bg-gris
              figure
                img(src="@/assets/template/tema-1-1.svg", alt="Texto que describa la imagen")
            .col-lg-8.bg-white.bg-amarillo
              .bloque-texto-b.p-4
                i.fas.fa-quote-left
                span.h4.mb-0 El merchandising es el mercadeo que seduce en el punto de venta” (Prieto, 2018, p. 11).
                i.fas.fa-quote-right 
    p.mt-5 La manera global de entender el merchandising de acuerdo con #[strong Prieto (2018)] es desglosar la palabra, así:
    .row.mt-5
      .col-10.offset-1.text-center
        figure
          img(src="@/assets/template/tema-1-2.png", alt="Texto que describa la imagen")
    .row.mt-5
      .col-12.col-md-7.p-5.bg-amarillo-claro.rounded
        p El merchandising es un conjunto de técnicas psicológicas de venta aplicadas de forma conjunta o separada por fabricantes y distribuidores, que actúan sobre la mente del comprador, con el objetivo de que satisfaga las necesidades que le llevaron al punto de venta, recuerde ciertas necesidades olvidadas y además sienta otras nuevas. #[strong La finalidad es que el comprador adquiera mayor cantidad y variedad de productos y con más frecuencia, consiguiendo así una mayor rentabilidad del punto de venta y de los productos (Escrivá, 2005).]
        p.mt-3 También integra las técnicas de comercialización que permiten presentar el producto en las mejores condiciones; esta es la manera de tener la mercancía adecuada en el lugar más conveniente con precios, cantidades y en el momento oportuno. Así, el merchandising es el conjunto de actividades que permiten una mayor valoración del producto por parte del consumidor en el punto de venta #[strong (Prieto, 2018).]
      .col-5.d-none.d-md-block.align-self-center
        figure.mb-5
          img(src="@/assets/template/tema-1-3.svg", alt="Texto que describa la imagen")
    .row
      .h4  El merchandising se puede referenciar desde:
      .col-sm.mb-5.mb-sm-0.mt-3
        ul.lista-ul
          li.mb-0 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-brain
              .col-11
                p Un punto de vista macro, como “la función comercial que tiene por objeto transformar las compras potenciales del consumidor en compras reales en el punto de venta”. 
          li.mb-0.mt-3 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-brain
              .col-11
                p Un punto de vista micro productor como “el conjunto de actividades publicitarias y promocionales a nivel de punto de oferta del producto, con el objeto de llamar la atención del consumidor hacia su producto”.
          li.mb-0.mt-3 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-brain
              .col-11
                p El punto de vista micro-distribuidor como “el conjunto de medios para asegurar la rentabilidad óptima del punto de oferta del producto” 
                h6 (Prieto, 2018).
    p.mt-5 Para #[strong Prieto (2018)], el merchandising tiene dos enfoques:
    .row.mt-3.justify-content-center
      .col-10.offset-2.mx-3.borde-top-gris.py-4
        .row
          .col-2.d-none.d-md-block.text-align-right(style='margin-right: -40px ;z-index:99')
            figure.mt-5
              img(src="@/assets/template/tema-1-4.svg", alt="Texto que describa la imagen")
          .col-12.col-md-9.borde-gris.p-5
            div.h6 Enfoque de la distribución (merchandising del punto de venta)
            p.mt-3 Cuando el merchandising se aborda desde la perspectiva de la distribución lo realizan principalmente los detallistas y se hace énfasis en el canal de distribución, cobertura de distribución, espacios, zonas, niveles, tiempos, distribución física o logística, etc.
    .row.mt-3.justify-content-center
      .col-10.offset-2.mx-3.borde-top-gris.py-4
        .row
          .col-2.d-none.d-md-block.text-align-right(style='margin-right: -40px ;z-index:99')
            figure.mt-5
              img(src="@/assets/template/tema-1-5.svg", alt="Texto que describa la imagen")
          .col-12.col-md-9.borde-gris.p-5
            h6 Enfoque de la comunicación (merchandising del fabricante)
            p.mt-3  Aquí, el merchandising es realizado por los integrantes del canal, en especial por los fabricantes, mediante técnicas de investigación y comunicación, estudio y análisis del mercado, diseño de envases, exhibiciones, publicidad en el punto de venta del fabricante, negociación de espacios, promoción de ventas, relaciones públicas, fuerza de ventas, etc. 
    figure.mt-5
      img(src="@/assets/template/tema-1-6.png", alt="Texto que describa la imagen")
    p.mt-5 Es importante resaltar que cualquier gestión de merchandising de acuerdo con #[strong Prieto (2018)] debe responder a las preguntas:
    .row.mt-4
      .col-sm.mb-5.mb-sm-0.mt-3
        ul.lista-ul
          li.mb-0 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Qué vender, para poder satisfacer las necesidades y deseos de los clientes y consumidores. 
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Dónde vender, para vender la imagen de la tienda y generar un ambiente agradable de compra. 
          li.mb-0.mt-2 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Cómo presentar los productos para seducir la venta o compra impulsiva.
    p.mt-5 Igualmente, #[strong Prieto (2018)] indica las principales funciones del merchandising, a saber:
    .row.mt-4
      .col-sm.mb-5.mb-sm-0.mt-3
        ul.lista-ul
          li.mb-0 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Aumentar la rotación de los productos en el punto de venta.
          li.mb-0.mt-2 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Atender con mayor calidad al cliente.
          li.mb-0.mt-2 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Crear un ambiente agradable para la venta.
          li.mb-0.mt-2 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Dar vida al producto en los sitios de venta.
          li.mb-0.mt-2 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Distribuir la superficie de venta.
          li.mb-0.mt-2 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Identificar las necesidades internas de capacitación en marketing.
          li.mb-0.mt-2 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Impulsar el acto de compra en el punto de venta.
          li.mb-0.mt-2 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Incrementar el posicionamiento de la organización.
          li.mb-0.mt-2 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Fomentar el tráfico de público en el establecimiento comercial.
          li.mb-0.mt-2 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Mejorar la exposición cualitativa de los productos.
          li.mb-0.mt-2 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Organizar las promociones en el punto de venta.
          li.mb-0.mt-2 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Optimizar los espacios disponibles en el lineal.
          li.mb-0.mt-2 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Potenciar y rentabilizar los espacios de venta.
          li.mb-0.mt-2 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Servir como canal de comunicación de la estrategia corporativa.
    .row.mt-5
      .col-
        .tarjeta-avatar-b.mb-5
          img(src='@/assets/template/tema-1-7.svg' alt='AvatarTop')
          .tarjeta.tarjeta--azul
            .p-4
              .h4 Beneficios del merchandising
              p El merchandising es importante en la medida en que produce valor agregado y crea diferenciación en la competencia. El merchandising es la sangre de las marcas, pues las alimenta, las hace crecer y progresar, las fortalece y las desarrolla al prolongar su vida y la de sus fabricantes. En cualquiera de los casos, el productor y el distribuidor deben trabajar juntos y apuntar hacia el mismo objetivo: el consumidor; pues al fin y al cabo lo único que cuenta es el resultado y ese se mide por la rentabilidad del negocio #[strong (Prieto, 2018).]    
    
    
    .h6.mt-5  Tipos de merchandising
    p.mt-2 Existen dos tipos de merchandising
    AcordionA.mt-5(tipo="a" clase-tarjeta="tarjeta tarjeta--gris")
      .row(titulo="Merchandising permanente")
        .col-4.d-none.d-md-block.px-5
          figure
            img(src="@/assets/template/tema-1-9.png", alt="Texto que describa la imagen")
        .col-md-8
          p Entendido como el conjunto de acciones que se lleva a cabo en los sitios donde normalmente están colocados los productos y servicios (Prieto, 2018). La distribución, colocación o ubicación que se encuentra día a día en el punto de venta incluye la disposición de los muebles y la organización de los productos dentro de la sala de ventas; se adopta un formato a largo plazo que persigue que el consumidor se familiarice con el sitio y pueda encontrar con facilidad lo que necesita #[strong (Martínez, 2018).]

      div(titulo="Merchandising promocional")
        .row(titulo="Merchandising permanente")
          .col-4.d-none.d-md-block.px-5
            figure
              img(src="@/assets/template/tema-1-10.png", alt="Texto que describa la imagen")
          .col-md-8
            p Es el que se lleva a cabo de manera simultánea con una campaña o una oferta del propio cliente y, que debe ser realizado no solo en el sitio principal del punto de venta, sino en otros lugares de este #[strong (Prieto, 2018).] La ubicación temporal de zonas para la colocación de muebles, productos y secciones dentro de la sala de ventas, que se desarrollan para respaldar actividades mutuales, eventos, promociones de ventas, lanzamientos, entre otros; en el retail estos espacios son arrendados a los proveedores, dueños de las marcas, por tiempos limitados y en lugares establecidos para tal fin #[strong (Martínez, 2018).]
    p.mt-5 Ahora bien, la implantación del merchandising dentro del establecimiento comercial se clasifica como se muestra en la siguiente figura.
    .row.bg-gris.mt-5
      .col-10.offset-1.mt-4
        figure
          img(src="@/assets/template/tema-1-11.png", alt="Texto que describa la imagen")
    p.mt-5 A continuación, observe la información que amplía esta clasificación:
    .row.mt-5
      .h6.mb-5 El merchandising de presentación
      .col-4.d-none.d-md-block.align-self-center 
        figure
          img(src="@/assets/template/tema-1-12.png", alt="Texto que describa la imagen")
      .col-md-8
        p Depende directamente de la tipología del producto y del tipo de establecimiento de atención al público, ya que basa y sustenta su existencia en la conquista de espacios en la sala de ventas, específicamente en las estanterías, góndolas, módulos, espacios o muebles en general dispuestos para tal fin. De esta manera, en la forma básica propende por presentar los artículos de la mejor forma posible para que sean apetecidos por los clientes, con surtidos aptos para el público objetivo de la tienda y, que a su vez sean rentables para el negocio. También busca colocar los productos a la vista del consumidor en presentaciones atractivas de fácil acceso y, fomentar la compra por impulso al “recordar” su existencia con su presencia efectiva en el momento de la compra #[strong (Martínez, 2018).]
    .row.mt-5
      .h6.mb-5 El visual merchandising 
      .col-4.d-none.d-md-block.align-self-center 
        figure
          img(src="@/assets/template/tema-1-13.png", alt="Texto que describa la imagen")
      .col-md-8
        p Cumple tres objetivos, transmitir la imagen de lo que es y lo que vende la tienda, generar un flujo de circulación de clientes “dirigido” y, provocar ventas por impulso. Las técnicas desarrolladas por este tipo de merchandising tienen la finalidad de presentar los productos en las mejores condiciones visuales y de accesibilidad con el fin de materializar la venta, apelando a todo lo que pueda hacerlos más atractivos y persuasivos, en definitiva, hacerlos más vendedores #[strong (Palomares, 2012).] 
        p.mt-4 Las empresas realizan actividades propias en el interior de cada establecimiento al usar la animación, habladores, volantes, muestras, cupones, descuentos, concursos, degustaciones, demostraciones y demás publicidad para lograr la preferencia de sus productos basados en la marca, la compra impulsiva, el desarrollo del producto o servicio y la investigación del comportamiento de los consumidores #[strong (Prieto, 2018).] 
    .row.mt-5
      .h6.mb-5 El merchandising de gestión
      .col-4.d-none.d-md-block.align-self-center 
        figure
          img(src="@/assets/template/tema-1-14.png", alt="Texto que describa la imagen")
      .col-md-8
        p Es aquel en el que el distribuidor desarrolla técnicas para presentar su punto de venta de manera atractiva para que los que entren compren los productos ofertados. La gestión de las existencias, del ambiente, del espacio, de las categorías y la gestión de la relación con el cliente son factores determinantes en este tipo de merchandising (Prieto, 2018).
        p.mt-4 Se optimiza el espacio de exhibición, el cual es ampliamente utilizado y desarrollado por el retail, dado que por el tamaño de sus establecimientos y la cantidad de referencias que manejan requieren una administración sobre sus exhibiciones adecuada, rentable, de constante seguimiento y con soporte tecnológico.  
        p.mt-4 Es importante disponer de las herramientas y de la información pertinente y necesaria para poder gestionar y rentabilizar cada centímetro de muebles y salas de ventas en general. Comúnmente, se realizan clasificaciones en familias, subfamilias, categorías, marcas, tamaños y variedades, y se tienen en cuenta factores como la rotación, el margen de utilidad, gestión y ventas que permitan dar un valor a cada centímetro cuadrado de la superficie de ventas #[strong (Martínez, 2018).]
    .row.mt-5
      .h6.mb-5 El merchandising de seducción 
      .col-4.d-none.d-md-block.align-self-center 
        figure
          img(src="@/assets/template/tema-1-15.png", alt="Texto que describa la imagen")
      .col-md-8
        p Es aquel que se hace donde está el consumidor; usa medios virtuales, invade con avisos y ofertas los hogares y oficinas con páginas de Internet, en las cuales el cliente escoge los productos y servicios, y estos se le envían a su casa #[strong (Prieto, 2018).]
    .row.mt-5
      .h6.mb-5 El merchandising de fidelización 
      .col-4.d-none.d-md-block.align-self-center 
        figure
          img(src="@/assets/template/tema-1-16.png", alt="Texto que describa la imagen")
      .col-md-8
        p Está encaminado a la satisfacción total del cliente y ligado a los programas de servicio al cliente, para ello se requiere un conocimiento pleno del consumidor, es aplicable a cualquier tipo de negocio que recopile la información suficiente para perfilar la tipología del consumidor. Sobre la base de este conocimiento se desarrolla valores añadidos que aumentan los niveles de satisfacción, al crear vínculos más fuertes al asociar la compra con su propia personalidad, esto incrementa de manera directa la frecuencia de compra y las ventas indirectas, lo cual se logra al ofrecer mayor comodidad y diferentes formas de ayuda y soporte, en pocas palabras, al pensar “como el cliente y en el cliente” #[strong (Martínez, 2018)]
        p.mt-4 La decisión de compra es el momento definitivo dentro de la transacción, es una situación en la que el consumidor trae a su mente todos aquellos esfuerzos que la empresa ha realizado para informar, recordar e incentivar la preferencia de un producto.
        p.mt-4 El merchandising actúa en el punto de venta como esa ayuda adicional o razón fundamental que convence al cliente que la elección que va a tomar es la mejor. Un producto o establecimiento ordenado, limpio, organizado, sorprendente, llamativo, comunicador, da confianza y sin lugar a dudas, participa activamente en la decisión de compra de un consumidor #[strong (Martínez, 2018).]
    p.mt-5 Por otra parte, #[strong Prieto (2018)] describe a las fases del proceso de la compra en los consumidores de la siguiente manera:
    .row.mt-5 
      .col-10.offset-1
        .cajon.color-primario.p-4.mb-4(style='background-color: rgba(214, 70, 38, 0.4)')
          .row
            .col-2.offset-1.d-none.d-md-block.align-self-center
              figure
                img(src="@/assets/template/tema-1-17.svg", alt="Texto que describa la imagen").w-75
            .col-12.col-md-8
              .h3.mt-4 Cliente mira:
              p.mt-3 La persona que entró al establecimiento comercial y miró el producto sin tener la intención firme de comprarlo. Por eso, se debe situar la mercancía en una posición tal que pueda ser observada por el cliente, es muy sencillo, nadie compra lo que no ve.
    .row.mt-3 
      .col-10.offset-1
        .cajon.color-primario.p-4.mb-4(style='background-color: rgba(214, 70, 38, 0.25)')
          .row
            .col-2.offset-1.d-none.d-md-block.align-self-center
              figure
                img(src="@/assets/template/tema-1-18.svg", alt="Texto que describa la imagen").w-75
            .col-12.col-md-8
              .h3.mt-4 Cliente siente:
              p.mt-3 La persona que entró al almacén miró el producto y pensó en la utilidad que podría “sentir” al comprarlo y se motiva a llevarlo. El establecimiento comercial debe descubrir los deseos ocultos del cliente e impulsar las bondades del producto o servicio para satisfacerlo.
    .row.mt-3 
      .col-10.offset-1
        .cajon.color-primario.p-4.mb-4(style='background-color: rgba(214, 70, 38, 0.2)')
          .row
            .col-2.offset-1.d-none.d-md-block.align-self-center
              figure
                img(src="@/assets/template/tema-1-19.svg", alt="Texto que describa la imagen").w-75
            .col-12.col-md-8
              .h3.mt-4 Cliente examina:
              p.mt-3 La persona que entró al punto de venta miró y sintió, entonces tomó el producto para reafirmar su deseo y asegurarse de que este puede satisfacer su necesidad. El establecimiento tiene que facilitar ese examen mediante una actividad conjunta de merchandising, a través de la cual se resuelven todas las probables dudas, inquietudes u objeciones sobre calidad, especificaciones técnicas, precio, uso, contenido, competencia y otras especificaciones.
    .row.mt-3
      .col-10.offset-1
        .cajon.color-primario.p-4.mb-4(style='background-color: rgba(214, 70, 38, 0.1)')
          .row
            .col-2.offset-1.d-none.d-md-block.align-self-center
              figure
                img(src="@/assets/template/tema-1-20.svg", alt="Texto que describa la imagen").w-75
            .col-12.col-md-8
              .h3.mt-4 Cliente compra:
              p.mt-3 La persona que entró a la tienda miró, sintió y examinó y, finalmente decidió adquirir el producto o el servicio. El establecimiento debe utilizar todas las estrategias de mercadeo y merchandising para dar una satisfacción total al cliente y lograr que vuelva al sitio de venta
    .row.mt-5
      .col-12.col-lg-6.align-self-center
        p El merchandising ejerce una labor significativa en la utilización y manejo de marcas y productos en lugares ajenos o extraños al sitio de venta; la existencia de manuales que indiquen la forma establecida de exhibición, de colocación, ubicación e incluso el tratamiento de las marcas trasciende hacia la identidad corporativa de una organización y, se convierte en uno de los mecanismos importantes para salvaguardar marcas y productos en cualquier lugar en que puedan ser visualizados, en otras palabras, protege uno de los activos más importantes de las organizaciones, la marca #[strong (Martínez, 2018).]
      .col-6.d-none.d-lg-block 
        figure
          img(src="@/assets/template/tema-1-21.svg", alt="Texto que describa la imagen")
    p.mt-5 #[strong Prieto (2018)] enuncia las siete “B” del merchandising:
    .row.mt-3
      .col-7.d-none.d-sm-block
        figure
          img(src="@/assets/template/tema-1-22.png", alt="Texto que describa la imagen")
      .col-12.col-sm-5.px-5
        .row
          .col-sm.mb-5.mb-sm-0
            ol.lista-ol--cuadro
              li 
                .lista-ol--cuadro__vineta(style='background-color: #97181A !important')
                  span.text-white 1
                | B uena limpieza del establecimiento.
              li 
                .lista-ol--cuadro__vineta(style='background-color: #97181A !important')
                  span.text-white 2
                | B uena colocación de los productos.
              li 
                .lista-ol--cuadro__vineta(style='background-color: #97181A !important')
                  span.text-white 3
                | B uena política de precios.
              li 
                .lista-ol--cuadro__vineta(style='background-color: #97181A !important')
                  span.text-white 4
                | B uena garantía de los artículos.
              li 
                .lista-ol--cuadro__vineta(style='background-color: #97181A !important')
                  span.text-white 5
                | B uena decoración del punto de venta.
              li 
                .lista-ol--cuadro__vineta(style='background-color: #97181A !important')
                  span.text-white 6
                | B uena atención al cliente.
              li 
                .lista-ol--cuadro__vineta(style='background-color: #97181A !important')
                  span.text-white 7
                | B uena cantidad de productos.
    .titulo-segundo.mt-5
      #t_1_1.h4 1.1  Establecimiento comercial
    p.mt-4 El establecimiento comercial es el área de venta donde se va a exhibir el producto, incluidos los muebles y accesorios necesarios para tal fin. La circulación permite el flujo normal de los clientes de manera confortable, logrando la finalización del acto de compra y venta. Dentro de estas áreas se pueden encontrar escaleras, pasillos, ascensores, cintas transportadoras, corredores, entre otros. 
    p.mt-3 Algunos negocios por sus particularidades pueden necesitar áreas de bodegaje, áreas de servicios como baños, vestidores, lobbies o áreas de entretenimiento como zonas infantiles, muy comunes en restaurantes, guarderías, en el retail o en zonas de espera y de gran cantidad de servicios. Todas estas áreas deben ser minuciosamente planeadas, pensadas para la comodidad, tranquilidad y en general, para el bienestar del comprador y de sus posibles acompañantes #[strong (Martínez, 2018).] 
    .row.mt-5
      .col-5.d-none.d-md-block 
        figure
          img(src="@/assets/template/tema-1-23.png", alt="Texto que describa la imagen")
      .col-12.col-md-7
        p La arquitectura exterior e interior del establecimiento comercial y la decoración de los espacios, unida a los elementos ambientales de temperatura, iluminación, aromas, colores y música se conjugan para crear atmósferas coercitivas, con el fin de provocar en el cliente un impulso consumista no dirigido a ningún artículo determinado #[strong (Palomares, 2012).]
        p.mt-3 El merchandising debe seducir de manera estratégica, es decir, no es solo la estética lo que prima sino el conocimiento sobre la perfecta ubicación de los bienes en estanterías y muebles adecuados para tal fin, el análisis y el estudio de distribución general de la tienda con el conjunto de productos, puntos de pago, baños, vestidores, pasillos, zonas de descanso, servicios adicionales, flujo de público y en general todo lo que pueda afectar una experiencia dentro de un establecimiento #[strong (Martínez, 2018).]
        p.mt-3 Para #[strong prieto (2018)] el escenario del merchandising es el lugar donde se acelera la venta, por lo tanto, debe contener las cinco “A” de la personalidad de un establecimiento comercial, agrupadas en: el aviso, el acceso, el armario, la atención y la animación, las cuales bien manejadas conllevan a vender más y, que tanto los colaboradores como los clientes se sientan más satisfechos. A continuación, se describen los elementos del escenario.
    .row.mt-5
      TabsB.color-primario.mb-5
        .py-4.py-md-5(titulo="Aviso" :icono="require('@/assets/template/icono-1-1.svg')")
          .row
            .col-12.col-md-8
              p Representa la identidad visual de una empresa y debe estar integrado en relación directa con la marca visual que identifica a la organización, el logotipo, el color, la tipografía, la señalética y el nombre.
          
            .col-md-3.mx-3
              figure
                img(src='@/assets/template/tema-1-24.png', alt='Texto que describa la imagen')
        .py-4.py-md-5(titulo="Acceso" :icono="require('@/assets/template/icono-1-2.svg')")
          .row
            .col-12.col-md-8
              p Un aspecto trascendental para el éxito de un establecimiento comercial es la accesibilidad o la forma de llegar e ingresar al mismo y debe fomentar la consecución de la mayor cantidad de visitas posibles, está la accesibilidad física, referida a la cercanía al parqueadero, la facilidad de transitar con el carro de la compra hacia el vehículo de transporte familiar o personal, las escalinatas extensas de ingreso, la seguridad externa e interna, el espacio para control, la iluminación, los productos y el mobiliario que se ve desde la entrada.
            .col-md-3.mx-3
              figure
                img(src='@/assets/template/tema-1-25.png', alt='Texto que describa la imagen')
        .py-4.py-md-5(titulo="Armarios, escaparates o mobiliario" :icono="require('@/assets/template/icono-1-3.svg')")
          .row
            .col-12.col-md-8
              p Deben ser un aspecto diferenciador de la competencia, dar muestra de la personalidad del establecimiento, ayudar al ingreso de clientes a la tienda, llamar la atención, fidelizar al cliente, atraer compradores y claro, ayudar a vender. Por ende, debe estar en afinidad con el mensaje que se quiere posicionar del local, en cuanto a exclusividad, diseño, selectividad o precio.
            .col-md-3.mx-3
              figure
                img(src='@/assets/template/tema-1-26.png', alt='Texto que describa la imagen')
        .py-4.py-md-5(titulo="Atención al cliente" :icono="require('@/assets/template/icono-1-4.svg')")
          .row
            .col-12.col-md-8
              p Se debe tener una visión clara del valor agregado que el cliente espera del establecimiento comercial. Por eso, es oportuno encontrar aquellas necesidades de los clientes que ni siquiera ellos se han dado cuenta que tienen. Todas las áreas funcionales de las empresas se tienen que reenfocar hacia la filosofía del servicio y esto se obtiene mediante la capacitación del cliente interno, teniendo gente preparada y motivada.
            .col-md-3.mx-3
              figure
                img(src='@/assets/template/tema-1-27.png', alt='Texto que describa la imagen')
        .py-4.py-md-5(titulo="Animación del escenario" :icono="require('@/assets/template/icono-1-5.svg')")
          .row
            .col-12.col-md-8
              p La animación es la sinergia entre la identificación de las zonas, la ubicación del mobiliario, el diseño de los pasillos, la organización del surtido y las estrategias de exhibición, los cuales se constituyen como factores impulsores de la compra y aumentan la permanencia del comprador dentro del punto de venta. El punto de venta tiene que cumplir las funciones básicas de informar, recordar, seducir y vender, pues es lo que persigue siempre toda acción de marketing
            .col-md-3.mx-3
              figure
                img(src='@/assets/template/tema-1-28.png', alt='Texto que describa la imagen')

    .titulo-segundo.mt-5
      #t_1_2.h4 1.2  Layout
    figure.mt-4
      img(src='@/assets/template/tema-1-29.png', alt='Texto que describa la imagen')    
    .row.mt-5
      .col-12.col-lg-6
        p Es un diseño y plano estratégico del establecimiento comercial que debe contener de manera clara y específica los diferentes espacios que se manejan en el interior y exterior del establecimiento comercial. En el caso del retail deben detallarse las secciones que se manejan, la disposición de góndolas, los pasillos de circulación, el área promocional, los espacios para arriendo, zonas de pago, la entrada, la salida, las zonas de bodega, las zonas de descargue, zonas comunes, los niveles, la ubicación de sanitarios, zonas de estacionamiento y zonas de ubicación de servicios adicionales como cajeros automáticos y demás.
        p.mt-3 Para las tiendas especializadas el establecimiento comercial se convierte en un gran protagonista dentro de la función de merchandising, por esto, la planeación correcta y previamente analizada de toda su ubicación es muy importante, decisiones como dónde colocar el punto de pago, dividir la entrada y la salida, ofrecer espacios de espera, vestidores, baños y zonas de recreación son puntos trascendentales dentro de la estrategia, en muchos casos son el factor determinante para poder pensar en crear planes de fidelidad con los clientes, un espacio reducido para un vestidor en un almacén de ropa, un baño incómodo en un restaurante o un punto de pago mal ubicado puede ser el detonante para que un cliente no vuelva #[strong (Martínez, 2018).] 
      .col-6.d-none.d-lg-block.align-self-center
        figure.mt-4
          img(src='@/assets/template/tema-1-30.svg', alt='Texto que describa la imagen')
    p.mt-5 #[strong Martínez (2018)] menciona las principales funciones del merchandising tal como puede observar en la tabla 1.
    .row.mt-5
      .col-10.offset-1
        .tabla-b.color-acento-contenido.mb-5
          .tabla-b__header
            .h6.mb-0.text-white Funciones
          table
            caption.mt-3 Referencia Tabla - Tomadas de El arte de seducir Martínez (2018)
            tr
              td Guía de ubicación estratégica dentro del establecimiento.
            tr
              td Análisis de ubicación lógica del surtido.
            tr
              td Visualización del diseño y disposición física de muebles y productos.
            tr
              td Análisis de áreas de tráfico.
            tr
              td Planeación para incentivar ventas no planeadas.
            tr
              td Simulador de acciones de merchandising.
    .titulo-segundo.mt-5
      #t_1_3.h4 1.3  Planogramas y planimetría
    figure.mt-4
      img(src='@/assets/template/tema-1-31.png', alt='Texto que describa la imagen')
    p.mt-5 Es la representación gráfica de la ubicación de los productos dentro de un mueble, para el retail generalmente en góndolas y su separación se hace por secciones, así se puede encontrar el planograma para la sección de lácteos, aseo personal, alimento para mascotas, etc. En tiendas especializadas se desarrolla para muebles de toda índole que hacen parte de la exhibición. El planograma muestra de manera detallada la forma de ubicación y la cantidad del producto que se expondrá en el frente de un mueble, se discrimina cada una de las marcas y presentaciones que harán parte de la exhibición. Estos espacios que ocupan las diferentes marcas han sido establecidos a través de la negociación efectuada entre el proveedor y el intermediario o en tiendas propias por diseño y estrategia del profesional de merchandising. El planograma debe utilizarse para cualquier mueble que exhiba mercancía #[strong (Martínez, 2018).] 
    .row.mt-4
      .col-12.col-md-6
        p La planimetría nace de la necesidad de los distribuidores o de los dueños de los establecimientos comerciales por satisfacer las presiones y las solicitudes de los fabricantes para lograr la mejor ubicación dentro del punto de venta.
        p.mt-5 Se puede decir que es una técnica de merchandising que permite organizar en una góndola, estante, mostrador y demás mobiliario del local, un grupo de productos similares y no similares, al tratar de dar a cada fabricante o marca aquel espacio acorde a su participación en el mercado, su rotación, margen de rentabilidad, ventas y estética de exhibición #[strong (Prieto, 2018).]
      .col-md-6.d-none.d-md-block.align-self-center
        figure.mt-4
          img(src='@/assets/template/tema-1-32.png', alt='Texto que describa la imagen')
    p.mt-5 #[strong Martínez (2018)] describe las utilidades del planograma como se muestra en la tabla 2.
    .row.mt-5
      .col-10.offset-1
        .tabla-b.color-acento-contenido.mb-5
          .tabla-b__header
            .h6.mb-0.text-white Utilidades del planograma
          table
            caption.mt-3 Referencia Tabla - Tomadas de El arte de seducir Martínez (2018)
            tr
              td Guía de ubicación estratégica de los productos.
            tr
              td Herramienta de trabajo para dar continuidad en cambios de personal.
            tr
              td Simulador de acciones de merchandising.
            tr
              td Planeador del desarrollo de imagen de la tienda.
            tr
              td Análisis de movimientos de productos en el mueble.

    .titulo-segundo.mt-5
      #t_1_4.h4 1.4 Mobiliario comercial
    .tarjeta.color-primario.text-white.p-3.mb-5
      .row.justify-content-around.align-items-center
        .col-3.col-sm-2.col-lg-1
          img(src="@/assets/template/icono-1-6.svg")
        .col
          .row.justify-content-between.align-items-center
            .col-8.mb-3.mb-sm-0
              .h5.mb-0 Mobiliario comercial.
              p En la siguiente presentación se describe el mobiliario que se utiliza comercialmente, por ello, se invita que la consulte.  
            .col-sm-auto
              a.boton.boton--b(:href="obtenerLink('/downloads/CF6_Mobiliario_Comercial.pdf')" target="_blank")
                span Descargar
                i.fas.fa-file-download
    .titulo-segundo.mt-5
      #t_1_5.h4 1.5 Estrategias de exhibición
    p.mt-5 Los productos se dan a conocer, reconocer, preferir y elegir por su notoriedad (calidad, puntos de venta, publicidad, marca, dinamismo comercial), identificación (envase, diseño, fácil clasificación, ubicación y buena información) y motivación (sistema de precios, tamaños e innovación). Las mejores ubicaciones son las que están en un lugar preferencial sobre el sentido del tráfico, se anticipan a la acción de los competidores, se hacen de frente al consumidor y están en pasillos de alto tráfico con excelente visibilidad. Es conveniente cambiar las exhibiciones por lo menos cada dos semanas, pues después de ese tiempo las ventas descienden aproximadamente en un 75 %, entonces se recomienda ubicar productos diferentes a los que se tenían en el mobiliario.
    figure.mt-4
      img(src='@/assets/template/tema-1-33.png', alt='Texto que describa la imagen')
    p.mt-5 En el mobiliario no exhiba más de dos marcas a la vez, salvo que sean complementarias y se quieran vender por paquetes. Asimismo, las promociones más efectivas no son las que se limitan al manejo exclusivo del precio sino las que, además de acciones sobre el precio, incluyen material POP, exhibiciones adicionales y publicaciones del cliente. La efectividad de la exhibición puede medirse con una excelente calidad de los productos, manejo de precios competitivos y un impulso de venta fuerte en el punto de venta (Prieto, 2018).
    p.mt-5 Para #[strong Prettel (2016)] las formas más comunes de seducción o persuasión de los clientes en el punto de venta son las siguientes:
    .row.mt-5
      .col-sm.mb-5.mb-sm-0.mt-3
        ul.lista-ul
          li.mb-0 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p La decoración del punto de venta y su entorno.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p La información clara y oportuna para lograr convencer al cliente acerca de las bondades del producto.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p El trato amable por parte de la impulsadora y del resto de personal del establecimiento.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Precios atractivos y promociones constantes son una forma efectiva de seducción de clientes.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p La música y la animación también les gusta a los clientes.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p La entrega de material POP.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Lugares para el descanso dentro del establecimiento, ya sea para el acompañante (niño, mamá) o para el mismo comprador.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Un buen número de cajas para pagos, ojalá clasificadas por la cantidad de productos a pagar.
    p.mt-5 #[strong Prettel (2016)] menciona algunas estrategias de merchandising en el punto de venta utilizadas en los supermercados, con las que se espera que el consumidor encuentre diferenciación.
    .row.mt-4
      .col-12.col-lg-7
        ul.lista-ul
          li.mb-0 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Tarjeta que acumula puntos, que después se pueden cambiar por productos. Esta estrategia estimula a los clientes leales del almacén.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Entrega de cupones para posterior cambio por productos especiales.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Descuentos relámpago.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Premios sorpresa en las cajas de pago.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Venta de productos genéricos, que por no estar identificados por una marca resultan más económicos para los clientes.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Un día especial de descuentos para cierta línea de productos.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Diseño atractivo para las góndolas.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Excelente presentación y capacitación del personal de televisión.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Presentación y distribución general del almacén.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Concentración por línea de productos, por ejemplo, productos para el aseo del hogar, para el aseo personal, lácteos, verduras y frutas, herramientas, entre otros.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Precio del producto en un lugar visible.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Liquidez en las cajas de pago para la devolución del saldo del dinero correspondiente, a fin de evitar que los clientes pierdan tiempo.
      .col-5.d-none.d-lg-block.align-self-center
        figure.mt-4
          img(src='@/assets/template/tema-1-34.png', alt='Texto que describa la imagen')

    .titulo-segundo.mt-5
      #t_1_6.h4 1.6  Visual merchandising
    figure.mb-5
      .video
        iframe(width="560" height="315" src="https://www.youtube.com/embed/6-iaznLZYTg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen)

    .titulo-segundo.mt-5
      #t_1_7.h4 1.7  Vitrinismo
    p.mt-5 Las vitrinas son un medio de la arquitectura exterior, mediante el cual el establecimiento vende su imagen. Deben reflejar con su diseño el estilo de la tienda, llamar la atención de los compradores (percepción) y estimular su imaginación. El diseño de la vitrina es un motivador para el ingreso al establecimiento por parte de transeúntes o visitantes regulares #[strong (Prettel, 2016).]
    p.mt-4 Si se trata de vitrinas de grandes dimensiones como las de los grandes almacenes, como de una simple vitrina en la entrada de una tienda, es necesario proyectarlos al detalle. Una vitrina bien resuelta no solo es un reclamo para entrar en una tienda, sino que refuerza la imagen de marca del establecimiento. Puede actuar como una herramienta publicitaria y dar una idea de lo que puede comprarse en la tienda #[strong (Morgan, 2016).]
    p.mt-4 Para Tony Morgan (2016) existen 3 tipos de vitrinas:
    AcordionA.mt-5(tipo="a" clase-tarjeta="tarjeta tarjeta--gris")
      .row(titulo="Vitrinas cerradas: ")
        .col-4.d-none.d-md-block.px-5
          figure
            img(src="@/assets/template/tema-1-35.png", alt="Texto que describa la imagen")
        .col-md-8
          p Suelen hallarse en los grandes almacenes, cerradas por un gran vidrio en la fachada (frente al público en la calle), una pared en la parte posterior, dos paredes laterales y una puerta, estas vitrinas parecen una habitación; su decoración resulta muy interesante precisamente porque solo se puede captar la atención del público desde un ángulo: la calle. Los escaparates cerrados requieren ser planificados cuidadosamente; por su considerable tamaño se necesita una gran cantidad de productos para llenarlos; los elementos de atrezo también son grandes e incluso desmontables, lo que incrementa su coste; sin embargo, pueden exhibirse artículos caros siempre que la puerta esté protegida y los clientes no puedan acceder a ellos e interferir en la presentación. Desde el punto de vista del diseño la decoración debe ser frontal, ya que solo se contemplará desde un ángulo.

      div(titulo="Vitrinas abiertas por detrás: ")
        .row(titulo="Vitrinas abiertas por detrás: ")
          .col-4.d-none.d-md-block.px-5
            figure
              img(src="@/assets/template/tema-1-36.png", alt="Texto que describa la imagen")
          .col-md-8
            p Estas vitrinas no tienen pared trasera y pueden disponer de paredes laterales; son la opción preferida para muchos comercios porque permiten contemplar el interior de la tienda desde fuera; sin embargo, por esta misma razón, el interior debe estar cuidado y atractivo en todo momento. Son escaparates más difíciles de realizar porque se ven desde el exterior y el interior; en ellos, a diferencia de los escaparates cerrados, los artículos de lujo no están protegidos, por lo que no resultarán adecuados para este tipo de escaparate. Otra circunstancia para tener en cuenta es la posibilidad de que los usuarios toquen los artículos expuestos. 
      div(titulo="Sin vitrina: ")
        .row(titulo="Sin vitrina: ")
          .col-4.d-none.d-md-block.px-5
            figure
              img(src="@/assets/template/tema-1-37.png", alt="Texto que describa la imagen")
          .col-md-8
            p Los centros comerciales suelen tener locales sin vitrina. Fuera del horario comercial, la parte frontal del establecimiento está expuesta a la vista del público con una única persiana metálica de separación, al no tener puerta, ni ningún tipo de división que frenen la entrada de los clientes, en este tipo de establecimientos se pretende que el público acceda al interior y circule libremente. Parece, pues, que no existe ningún requisito de diseño en este sentido; sin embargo, es adecuado que los artículos se exhiban justo en la entrada con presentaciones orientadas a atraer a los consumidores.
    p.mt-5 #[strong Prettel (2016)] describe a continuación los aspectos para el diseño de vitrinas o escaparates:
    AcordionA.mt-5(tipo="a" clase-tarjeta="tarjeta tarjeta--gris")
      .row(titulo="Vitrinas para temporadas especiales:  ")
        .col-4.d-none.d-md-block.px-5
          figure
            img(src="@/assets/template/tema-1-38.png", alt="Texto que describa la imagen")
        .col-md-8
          p La navidad es una época en que las vitrinas deben en su diseño despertar el espíritu navideño, afectando los sentimientos que se despiertan en esta época para el consumidor y la propensión a la compra.

      div(titulo="Las vitrinas para promociones:  ")
        .row(titulo="Las vitrinas para promociones: ")
          .col-4.d-none.d-md-block.px-5
            figure
              img(src="@/assets/template/tema-1-39.png", alt="Texto que describa la imagen")
          .col-md-8
            p En estas se deben mostrar los artículos que al interior del establecimiento se encuentran en promoción de venta, por lo tanto, cada artículo debe tener su respectivo precio para que el posible comprador identifique lo atractivo de la promoción y estimule su ingreso.
      div(titulo="Vitrinas de surtido de productos y precios:  ")
        .row(titulo="Vitrinas de surtido de productos y precios:  ")
          .col-4.d-none.d-md-block.px-5
            figure
              img(src="@/assets/template/tema-1-40.png", alt="Texto que describa la imagen")
          .col-md-8
            p En estas vitrinas se trata de que el comprador potencial, con una mirada identifique rápidamente el producto que le gusta e identifique el precio que se acomode a su presupuesto. Esto resulta ser una comunicación importante que estimula el ingreso al establecimiento y que puede agilizar el proceso de compra; este tipo de vitrina es muy utilizada por empresas de calzado y ropa deportiva.
      div(titulo="Vitrinas interactivas:")
        .row(titulo="Vitrinas abiertas por detrás:")
          .col-4.d-none.d-md-block.px-5
            figure
              img(src="@/assets/template/tema-1-41.png", alt="Texto que describa la imagen")
          .col-md-8
            p En estas se ofrecen todos los productos en lugares visibles que causen impacto. En la actualidad con el uso de las tecnologías se pueden transformar las vitrinas en pantallas interactivas de gran tamaño.
      div(titulo="Vitrinas temáticas:")
        .row(titulo="Vitrinas temáticas:")
          .col-4.d-none.d-md-block.px-5
            figure
              img(src="@/assets/template/tema-1-42.png", alt="Texto que describa la imagen")
          .col-md-8
            p Se refieren al concepto creativo que se utiliza para apoyar un producto; ambos están relacionados y ofrecen a la vitrina el hilo conductor que une todo el proyecto; un tema o esquema debe estar bien planificado y aplicado a todo el proyecto; se emplean para crear mayor dramatismo, narrar una historia e inspirar al comprador y pueden estar asociados a una temporada determinada o relacionados con tendencias sociales, políticas o económicas #[strong (Morgan, 2016).]
    .titulo-segundo.mt-5
      #t_1_8.h4 1.8  Punto de venta
    figur.mt-5
      img(src="@/assets/template/tema-1-43.png", alt="Texto que describa la imagen")
    p.mt-5 Más del 70% de las decisiones de compra se toman cuando el consumidor está en el punto de venta. El objetivo del marketing experiencial en el establecimiento es guiarle, sorprenderle, conectar con él para facilitar su decisión, creando para ello actividades originales, a menudo interactivas, que implican los sentidos e invitan a la acción #[strong (Manzano, 2012).]
    .h5.mt-5 Zonas del punto de venta
    p.mt-4 Se ha demostrado que las personas cuando ingresan a una tienda o local se dirigen hacia el centro de esta y luego giran a la izquierda en sentido concéntrico, lo cual hace prever la tendencia de ubicar las entradas en el lado derecho del establecimiento #[strong (Prieto, 2018).]
    .row.mt-5
      TabsB.color-primario.mb-5
        .py-4.py-md-5(titulo="Zona caliente")
          .row
            .col-md-3.mx-3
              figure
                img(src='@/assets/template/tema-1-44.png', alt='Texto que describa la imagen')
            .col-12.col-md-8
              p Es aquel lugar del punto de venta en el que el volumen de ventas de cualquier producto exhibido es mayor por metro lineal que el promedio de venta del establecimiento comercial; es el lugar o el sitio de compra donde el paso de las personas es superior a la media de la zona. Esta es considerada como la zona más cercana al punto de acceso al área de venta, es decir, por donde los clientes caminan de forma normal sin importar lo que busquen y, por ello, se deben colocar las secciones de productos de menor rotación; esta zona debe abarcar entre el 80 y el 90% del área de ventas como mínimo #[strong (Prieto, 2018).]
        .py-4.py-md-5(titulo="Zona fría" )
          .row
            .col-md-3.mx-3
              figure
                img(src='@/assets/template/tema-1-45.png', alt='Texto que describa la imagen')
            .col-12.col-md-8
              p Es aquel lugar del punto de venta en el que el volumen de ventas de cualquier producto exhibido es menor por metro lineal que el promedio de venta del establecimiento comercial; es el lugar o sitio de compra donde el paso de las personas es menor que la media de la zona. Esta es considerada como la zona más alejada del punto de acceso al área de ventas, es decir, por donde los clientes transitan poco, por ejemplo, rincones, pilares, cuellos de botella, escaleras, pasillos estrechos, pasillos ciegos, exceso de ruido y señalización deficiente, entre otros, y donde deben colocarse las secciones de productos de mayor rotación. Esta zona debe abarcar entre el 10 y el 20% del área de ventas como máximo #[strong (Prieto, 2018).]
              p.mt-4 Se recomienda que para convertir las zonas frías en calientes se utilicen técnicas de animación como: colocar productos básicos en zonas frías, iluminar de manera intensa la zona afectada, montar stands con degustaciones, cubrir dicha zona con espejos, tener promociones regulares en la zona fría y contar con una capacitación permanente para el personal de merchandising #[strong (Prieto, 2018).]
    .h5.mt-5  Contribución del distribuidor en el punto de venta
    p.mt-4 #[strong Prettel (2016)] determina para la buena gestión del merchandising que el distribuidor realice los siguientes aportes al punto de venta:
    .row.mt-4
      .col
        ul.lista-ul
          li.mb-0 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p #[strong Ubicación de los productos en el espacio del canal de distribución:] los productos se deben ubicar en el punto de venta de acuerdo con su función; generar lo que se denomina mercado concentrado dentro del canal, por ejemplo, de los productos lácteos juntar todas las marcas, al igual que los detergentes, productos para el aseo personal (desodorantes, talcos), marcas de café y sus complementos, etc. Este orden agiliza en el consumidor el proceso de compra de todo el mercado.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p #[strong Organización de los productos en la góndola:] los productos deben organizarse de manera estética, y de la manera que se facilite la toma por parte del comprador. Igualmente, su organización debe facilitar la lectura de la etiqueta sin tener que recurrir a tomarlo con la mano.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p #[strong Diseño de la estructura organizativa de los espacios:] el manejo de toda la arquitectura que forma el espacio del canal incide en que sea visitado de manera constante por una gran masa de compradores. Es importante, por lo tanto, el buen manejo de espacios amplios, el tipo de estanterías, muebles en general, la decoración, la luz y la ubicación de los precios.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p #[strong Control sobre la limpieza del punto de venta:] en esta gestión juega un gran papel las impulsadoras del producto, que en muchas ocasiones dependen laboralmente de la empresa productora. Pero, aún así, debe ser una preocupación del distribuidor el control de estas promotoras para que desarrollen una buena labor.
    .h5.mt-5  Marketing sensorial en el punto de venta
    .row.mt-4
      .col-12.col-lg-7.align-self-center
        p Consiste en utilizar elementos ambientales de la tienda con el fin de actuar sobre los sentidos del consumidor para generar las reacciones afectivas, cognitivas y de comportamiento que favorezcan la creación de imagen de marca y estimulen la compra #[strong (Manzano, 2012).]
      .col-4.mx-3.d-none.d-lg-block
        figure
          img(src='@/assets/template/tema-1-46.svg', alt='Texto que describa la imagen')
    .row.mt-5
      .col-12
        p.mb-5  A continuación, puede observar la relación de sentidos y acciones incluidos en el marketing sensorial del punto de venta.
        .tabla-a.color-primario.mb-5 
          table
            caption Referencia Tomada de Marketing sensorial. Comunicar los sentidos en el punto de venta Manzano (2012)
            thead
              tr
                th(colspan='2').h5 Relación de sentidos y acciones
            tbody
              tr.text-white.bg-primario
                th Sentido
                th Acciones
              tr.bg-gris
                td Vista
                td(style='text-align: left; font-weigth:700;') 
                  .h7.mt-3.font-weight-bold Colores utilizados en la decoración ambiental.
                  .h7.mt-2.font-weight-bold Iluminación utilizada.
                  .h7.mt-2.font-weight-bold Arquitectura interior.
                  .h7.mt-2.font-weight-bold Ambientes temporales creados.
                  .h7.mt-2.font-weight-bold Exposición de los propios artículos.
              tr
                td Tacto
                td(style='text-align: left') 
                  .h7.mt-3.font-weight-bold Materiales utilizados. 
                  .h7.mt-2.font-weight-bold Temperatura y humedad de la tienda.
                  .h7.mt-2.font-weight-bold Accesibilidad al producto.
              tr.bg-gris
                td Olfato
                td(style='text-align: left') 
                  .h7.mt-3.font-weight-bold Aromas de ambiente global. 
                  .h7.mt-2.font-weight-bold Aromas de ambientes específicos.
                  .h7.mt-2.font-weight-bold Aromas de productos.
              tr
                td Oído
                td(style='text-align: left') 
                  .h7.mt-3.font-weight-bold Música ambiental.
                  .h7.mt-2.font-weight-bold Ruido generado en la tienda.
                  .h7.mt-2.font-weight-bold Sonido de los propios productos.
              tr.bg-gris
                td Gusto
                td(style='text-align: left') 
                  .h7.mt-3.font-weight-bold Degustaciones de productos en el punto de venta.
                  .h7.mt-2.font-weight-bold Comidas y bebidas servidas en los servicios de la tienda.
                  .h7.mt-2.font-weight-bold Venta de productos para su consumo fuera de la tienda.
    .titulo-segundo.mt-5
      #t_1_9.h4 1.9  Marketing sensorial
    figure.mt-5
      .video
        iframe(width="560" height="315" src="https://www.youtube.com/embed/IGkxacxdlAY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen)
    p.mt-5 La nueva experiencia de ir de compras incluye la aventura que supone la exploración de los establecimientos, escaparates y surtidos, localización y adquisición de bienes o servicios; pero trasciende al propio producto para convertirse, por sí misma, en una fuente de gratificación para el consumidor que se traduce en entretenimiento y placer; un placer que no está necesariamente relacionado con el gasto realizado, sino más bien con la adquisición de un conocimiento actualizado del mercado: novedades, modas, tendencias, etc.
    p.mt-4 No es raro escuchar expresiones como “me gusta comprar”, “me divierte ir de tiendas” o incluso “voy de compras para distraerme o relajarme”. En ellas no se especifica el producto que se desea adquirir, sino que se centran exclusivamente en la actividad a realizar que es visitar y permanecer tiempo en establecimientos comerciales, y de manera sobreentendida, a las emociones que esa actividad genera como alegría, diversión, agrado, euforia no exenta eventualmente de frustración o enfado. El origen de estas emociones nos remite a los estímulos sensoriales que configuran los espacios comerciales, como son los ambientales, el diseño, la música, la temperatura, el olor, la variedad de la oferta y su adaptación al perfil del cliente, su predisposición natural hacia la actividad y el momento o circunstancia vital en que se encuentra #[strong (Manzano, 2012).]
    .row.mt-5
      .col-10.offset-1
        .bloque-texto-a.color-acento-contenido.p-4.p-md-5.mb-5 
          .row.m-0.align-items-center.justify-content-between
            .col-lg-4.mb-4.mb-lg-
              figure
                img(src="@/assets/template/tema-1-47.svg", alt="Texto que describa la imagen")
            .col-lg-8.bg-white.bg-rojo-claro
              .bloque-texto-b.p-4
                span.mb-0 Adiós producto, adiós servicio, bienvenida la experiencia; una experiencia se define como un suceso privado que tiene lugar como consecuencia de una estimulación inducida, esto es, un estímulo que se produce en el exterior y le llega al sujeto, quien lo encuentra, lo vive o pasa por ello. Las experiencias se inician o desencadenan fuera de nosotros y se convierten en lo que son cuando las hacemos nuestras #[strong (Manzano, 2012).]
    p.mt-5 El desarrollo de nuevas tendencias científicas enlazadas a la tecnología permite realizar y pensar en implementaciones, encaminadas a sobrepasar el tradicional estímulo visual y trasladarlo a otros sentidos, #[strong (Martínez, 2018).] A partir de ello, observe la información que aparece a continuación, correspondiente a cada sentido.
    AcordionA.mt-5(tipo="b" clase-tarjeta="tarjeta tarjeta--gris")
      .row(titulo="Vista")
        figure
          img(src="@/assets/template/tema-1-48.png", alt="Texto que describa la imagen")
        p.mt-4 Es el principal vehículo de aprendizaje del ser humano, se podría decir que los ojos son como una videocámara incorporada en el organismo que permite registrar todo lo que nos interesa a nuestro alrededor #[strong (Manzano, 2012).]
        p.mt-4 A continuación, #[strong Manzano (2012)] menciona algunos factores para tener en cuenta sobre el sentido de la vista.
        .row.mt-4
          .col
            ul.lista-ul
              li.mb-0 
                .row
                  .col-1.text-align-right.p-0
                    i.fas.fa-angle-right
                  .col-11
                    p  #[strong Inconsciencia:] no se es consciente de todo lo que se ve, a diferencia de otros sentidos el sentido visual percibe estímulos que están por debajo del umbral de detección consciente; existen estímulos visuales que se perciben conscientemente y otros que se perciben de forma inconsciente o subliminal.
              li.mb-0.mt-2
                .row
                  .col-1.text-align-right.p-0
                    i.fas.fa-angle-right
                  .col-11
                    p #[strong La percepción visual es selectiva,] es decir, los individuos no son conscientes de todo lo que ocurre a su alrededor y, por tanto, seleccionan lo que ven. Esto significa que los individuos seleccionan de modo inconsciente lo que consideran más relevante para ellos en ese momento; se ve lo que se quiere. 
              li.mb-0.mt-2
                .row
                  .col-1.text-align-right.p-0
                    i.fas.fa-angle-right
                  .col-11
                    p  #[strong Árbitro de conflictos:] la vista es el sentido que más activa el proceso cognitivo y participa en el proceso de aprendizaje. De este modo, si lo que se ve contradice lo que se siente, se escucha o se huele, se produce una disonancia cognitiva en el individuo; en los sentidos se tiende a priorizar el sentido de la vista como el predominante, esta peculiaridad implica que la vista suele tener la última palabra en su interacción con otros sentidos.
      div(titulo="Olfato")
        figure
          img(src="@/assets/template/tema-1-49.png", alt="Texto que describa la imagen")
        p.mt-4 La fuerza evocadora de los olores era mucho más intensa; el olfato se conoce también como el sentido silencioso, por lo difícil que resulta describir con palabras los olores o los sentimientos de bienestar que muchas veces llevan asociados. El marketing olfativo contempla dos cualidades básicas de los aromas para evaluar su uso: placer y congruencia; la primera, el placer, recoge la experiencia intrínseca del olor, mientras que la congruencia conecta el olor con el contexto: tienda, producto o marca #[strong (Manzano, 2012).]
        p.mt-4 En el caso del olfato, estudios adelantados permiten concluir que las sensaciones olfativas producen recordación y evocación de lugares, espacios y, por supuesto, de marcas de productos.
        p.mt-4 Existen productos que por su propia estructura son constituidos por fragancias y aromas que se convierten en sus principales atributos, el aroma de una libra de café o de uno ya preparado, los alimentos, los cosméticos y los perfumes son ejemplos de productos que traen consigo un atributo diferenciador de vital importancia en la estrategia de producto; pero hay otros productos cuyo aroma o fragancia no hace parte de las características de mayor trascendencia y que pueden ser susceptibles de trabajarse, incluso en ítems cuya relación con el olfato podría estar bastante lejana, tal es el caso de la marca de zapatos infantiles Bubble Gummers, en la que se introdujeron materiales con un olor característico, muy parecido al chicle, lo que hace que nadie se resista a ver estos zapatos exhibidos sin acercarlos a su nariz, casi como efecto reflejo #[strong (Martínez, 2018).]
        p.mt-4 #[strong Martínez (2018)] describe en la tabla 4 algunos aromas con su efecto a partir de estudios de la marca española Aromarketing.
    .row.mt-5
      .col-12
        .tabla-a.color-primario.mb-5 
          table
            caption Referencia Tomado de El arte de seducir Martínez (2018)
            thead
              tr
                th(colspan='2').h5 Efecto de los aromas
            tbody
              tr.text-white.bg-primario
                th Aroma
                th Efecto
              tr.bg-gris
                td.text-center Vainilla
                td(style='text-align: left').font-weight-bold Para tiendas de ropa que se relacionan con la limpieza, la elegancia y la vanidad, especialmente en los establecimientos de moda femenina.
              tr
                td.text-center Cuero
                td(style='text-align: left').font-weight-bold Transmite la sensación de elegancia, de calidad y sofisticación, y se utiliza en zapaterías. 
              tr.bg-gris
                td.text-center Pasto recién cortado
                td(style='text-align: left').font-weight-bold Da la sensación de frescura, reanima e invita a la actividad física, por lo que suele utilizarse en lugares de venta de herramientas, materiales para construcción o decoración.
              tr
                td.text-center Chocolate, galletas o manzana/canela
                td(style='text-align: left').font-weight-bold Evocan el hogar, dan nostalgia, felicidad y tranquilidad, por lo que se utilizan en tiendas de decoración de interiores, pero como también despiertan el apetito, pueden usarse en pastelerías, cafeterías, etc. Incluso podemos encontrar estas fragancias en agencias inmobiliarias o dentro de las casas que se encuentran a la venta, pues el olor a pan hace sentir al cliente como en casa.
              tr.bg-gris
                td.text-center Talco para bebés
                td(style='text-align: left').font-weight-bold Relacionado con el cuidado materno, se encuentra en fragancias, clínicas, consultorios ginecológicos o pediátricos y tiendas de ropa y accesorios para bebé.
              tr
                td.text-center Chicle
                td(style='text-align: left').font-weight-bold Aroma infantil, fresco y atractivo, ideal para almacenes para niños.
              tr.bg-gris
                td.text-center Madera
                td(style='text-align: left').font-weight-bold Aroma elegante, sofisticado y muy masculino, es un energizante que ayuda a eliminar el estrés, lo encontramos en vinotecas, bodegas de licores y en tiendas de ropa para caballeros.
              tr
                td.text-center Cítricos
                td(style='text-align: left').font-weight-bold Transmiten la sensación de limpieza y frescura, además ayuda a reducir el estrés, y se utiliza en consultorios, hospitales, etc.
              tr.bg-gris
                td.text-center Lavanda
                td(style='text-align: left').font-weight-bold Un aroma con efecto sedante que se recomienda para calmar el estrés y el nerviosismo.
    .row.mt-5
      .col-12.col-lg-6.align
        p Su desarrollo es complejo y requiere el concurso de varias disciplinas con amplio conocimiento en el consumidor, su psicología y químicos especializados en aromas, los cuales a través de un minucioso análisis físico y sensorial de los productos determinan la posibilidad de inclusión del aroma dentro de sus atributos o del desarrollo de un olor que de manera independiente al producto interactúe con los consumidores, para determinar el posicionamiento más adecuado que deberá manejarse al desarrollar un olor exclusivo para la marca  #[strong (Martínez, 2018).]
        figure.mt-4.d-none.d-lg-block
          img(src="@/assets/template/tema-1-50.png", alt="Texto que describa la imagen")
      .col-12.col-lg-6.mt-4.mt-lg-0
        p La respuesta más inmediata y básica ante cualquier aroma es de naturaleza hedónica: gusta o disgusta, por ello, los aromas se clasifican con el mismo y sencillo criterio que se limita a agruparlos en agradables o desagradables; un olor considerado agradable combina tres aspectos: tono, intensidad y familiaridad. El tono se refiere a la naturaleza afectiva de un aroma, su esencia, algo similar al matiz en el color. La intensidad indica el grado de concentración del aroma. La familiaridad es lo conocido que resulta un olor para quien lo percibe, cuanto más familiar es un aroma más probabilidad hay de que el sujeto lo asimile a la categoría agradable y, por el contrario, los olores agradables tienden a ser percibidos como familiares #[strong (Manzano, 2012).]
        p.mt-4 El sistema de clasificación de las fragancias de un perfume empleado en el mundo de la perfumería se denomina nota alta, que se refiere a los olores de elevada intensidad, que se detectan rápidamente y cuyo papel es provocar la primera impresión, atrapar e impactar. Las notas medias se les considera el corazón de un perfume porque contienen la fragancia más importante y proporcionan el verdadero espíritu que le caracteriza; su duración es aproximadamente de cuatro horas. Por último, las notas bajas corresponden a aromas muy duraderos, de muy baja intensidad y cuyo papel es fijar el perfume y darle una armonía global.
    p.mt-4 La marca olfatoria #[strong (scent brand)] constituye una decisión tan trascendente como la elección de un logotipo, un color o una tipografía; se trata de un aroma que identifica a la marca de forma única y exclusiva en el largo plazo como parte de su logotipo, busca una sinergia entre ambos elementos, destinados a reforzar significados o a desarrollar ciertas emociones en un código más eficaz.
    AcordionA.mt-5(tipo="b" clase-tarjeta="tarjeta tarjeta--gris")
      .row(titulo="Audición")
        figure
          img(src="@/assets/template/tema-1-51.png", alt="Texto que describa la imagen")
        p.mt-4 El sentido del oído está constantemente activo, desde que se nace hasta que se muere, todos los días del año, durante las veinticuatro horas del día; los oídos trabajan también mientras se duerme, aunque no se esté consciente de ello #[strong (Manzano, 2012).]  
        p.mt-4 Los sonidos están íntimamente ligados a la vida cotidiana, desde el momento de despertar se vive y se interactúa con diversidad de sonidos que producen, en su mayor parte, identificaciones y, por lo tanto, evocaciones de diferente índole. El sonido de la identificación de ciudad está relacionado con sonidos de automóviles, pitos y muchos sonidos agregados, los cuales transmiten sensaciones de estrés; caso contrario sucede con la identificación del campo, relacionado con la placidez y que se da a través de sonidos de pájaros, brisa, agua y mar, los cuales logran definitivamente proporcionar tranquilidad #[strong (Martínez, 2018).]
        p.mt-4 Es importante que esa creación de audiotipos y búsqueda de la música y sonidos más adecuados esté relacionada íntimamente con el trabajo visual y olfativo que se realice, al tener en cuenta que cada espacio donde interactúe el producto es diferente y, por lo tanto, susceptible de ser revisado para su aplicación puntal, un producto tendrá diferentes relacionamientos con sus clientes por diversos aspectos, como ubicación, clima, cultura, espacio y demás que afecten de manera clara la experiencia #[strong (Martínez, 2018).]
        p.mt-4 Es habitual escuchar música de fondo en los establecimientos comerciales. Las voces de la megafonía anunciando promociones en los hipermercados captan la atención con cierta frecuencia mientras las personas llenan el carro de la compra, y cada vez más a menudo se enfrentan a las voces de los contestadores automáticos que repiten sus mensajes con voz impersonal #[strong (Manzano, 2012).]
        p.mt-4 Evocador de recuerdos. El ser humano posee la capacidad de asociar sensaciones procedentes de los cinco sentidos y relacionarlas con conceptos e ideas, que a su vez generan sentimientos y emociones que le recuerdan sus experiencias vitales. El oído tiene un efecto inmediato sobre el recuerdo; se sabe que la fuerza evocadora de la música es capaz de transportar a las personas a lugares y dimensiones temporales remotas de la vida. Los sonidos forman parte natural del entorno humano y crean asociaciones o evocan recuerdos que los responsables de marketing pueden integrar de forma muy rentable en sus estrategias de marketing sensorial #[strong (Manzano, 2012).]
        p.mt-4 La voz es otro elemento importante para el marketing de los sentidos, es un sonido muy poderoso; la voz, al igual que las huellas dactilares, es única e irrepetible. Las voces elegidas para los anuncios televisivos y de radio son seleccionadas cuidadosamente para transmitir seguridad, sensualidad, acción o cercanía. La voz tiene la cualidad de permitir expresar mucho más de lo que se dice con simples palabras; existe un metalenguaje que transmite las emociones, el contexto o las intenciones, que puede alterar el sentido de lo que se dice mediante la ironía o el sarcasmo, o modulando el tipo de voz –seria, enfadada, cariñosa– #[strong (Manzano, 2012).]
        p.mt-4 La música de fondo ha sido utilizada tradicionalmente para amenizar el punto de venta. La importancia de la música que suena en un establecimiento radica en la influencia que ejerce en la conducta del consumidor; que compre más, que compre menos, que alargue su estancia en una tienda o que salga de ella antes de haber terminado su compra. El tempo, el ritmo, los instrumentos o la novedad de la pieza influyen en el estado de ánimo de quien escucha; la música energética con tempo rápido provoca más sentimientos positivos que la música lenta y sedante.
      div(titulo="Gusto")
        figure
          img(src="@/assets/template/tema-1-52.png", alt="Texto que describa la imagen")
        p.mt-4 Es el más íntimo de todos los sentidos del ser humano, en la medida en que implica el contacto interior, directo y, durante cierto tiempo, del individuo con el producto en la boca. Para conseguir este contacto el producto tiene que pasar por la totalidad del resto de los sentidos, que actúan como filtros; una inspección táctil a través de los labios y de la propia lengua, que evalúan y mandan información al cerebro sobre la consistencia del producto a probar, su sabor, textura y temperatura #[strong (Manzano, 2012).]
        p.mt-4 Se habla de cuatro sabores básicos: dulce, salado, ácido y amargo. Los otros sentidos son condicionantes del sentido del gusto, así como el efecto que pueden ejercer la publicidad, la marca comercial y las connotaciones que esta tiene: el nombre del plato en la carta de un restaurante, los ingredientes que figuran en el envase de un producto, etc. Una etiqueta que indique un alto contenido en grasa para un producto transmite una mayor percepción de sabor, e incluso un producto con una fecha de caducidad más próxima que otro va a percibirse como menos sabroso. El gusto está muy influido por factores ambientales y sociales; por el entorno más cercano, por el motivo de la comida, por la gente con quien se comparte, es decir, la implicación emocional y la predisposición con que se aborda #[strong (Manzano, 2012).]
        p.mt-4 Degustaciones de productos en el punto de venta. Dado el enorme poder emocional que tiene el sentido del gusto es evidente que cuando se habla de productos de alimentación, la prueba de producto en la tienda es un elemento importante para generar conocimiento y aceptación de este. Cuando se trata de detallistas especializados en una determinada categoría de productos de alimentación, casi siempre se utiliza la degustación dentro del punto de venta como una herramienta de atracción para incentivar la compra #[strong (Manzano, 2012).]
      div(titulo="Tacto")
        figure
          img(src="@/assets/template/tema-1-53.png", alt="Texto que describa la imagen")
        p.mt-4 Basta con observar detenidamente al consumidor mientras compra para comprobar la importancia que para el ser humano tiene el sentido del tacto; tocar un producto supone un medio fundamental para generar la información o emoción que una vez integrada como percepción en el comportamiento del consumidor facilite la decisión de compra #[strong (Manzano, 2012).]
        p.mt-4 La influencia del tacto no se reduce a afectar al resto de los sentidos. El contacto directo y casual entre personas provoca sensación de proximidad, afecto y calidez en su destinatario, afectando positivamente tanto a la valoración de los estímulos en los que se produce ese contacto, como a una mejor valoración del prestatario. El contacto supone una oportunidad para la venta personal y una forma de diferenciarse de la venta online; por su parte, la venta online debe compensar su despersonalización, ya sea por medio de servicios de asistencia personal online o telefónica, o a través de personajes automatizados #[strong (Manzano, 2012).]
        p.mt-4 Los beneficios que proporciona el tacto al consumidor son múltiples. El primero permite aportar valor a los distintos parámetros físicos de un producto en relación con una necesidad del cliente; facilita información directa, obtenida personalmente por el comprador, sobre aquellos elementos físicos en los que el consumidor necesita saber más para generar una percepción que facilite su decisión. Este factor es fundamental especialmente en aquellos productos en los que la calidad puede valorarse a partir de esta inspección táctil, por lo que se convierte en la principal fuente para tomar una decisión, por encima de cualquier otra vía de comunicación. El acceso a un producto refuerza la confianza en la evaluación hecha sobre este y, en la decisión de compra realizada también funciona en el sentido contrario; un deficiente acceso al producto en un punto de venta genera una información incompleta, y sobre todo genera desconfianza por parte del consumidor, tanto en su valoración como en el propio punto de venta #[strong (Manzano, 2012).]
    p.mt-5 Según #[strong Manzano (2012)] las principales áreas de atracción del marketing sensorial son las que se describen en la figura 3.
    p.mt-4 #[strong Figura 3] Áreas de atracción del marketing sensorial
    .row.mt-5
      .col-7.col-lg-5.offset-3.bg-gris
        figure
          img(src="@/assets/template/tema-1-54.png", alt="Texto que describa la imagen")
          figcaption Referencia Tabla - Manzano (2012).
    .titulo-segundo.mt-5
      #t_1_10.h4 1.10  Teoría del color
    .row.mt-5
      .col-12.col-lg-7.align-self-center
        p El color está ligado a la parte emocional de la percepción; junto con la iluminación y la textura logran atrapar la atención antes que la forma, más vinculada a la razón; por naturaleza es inseparable de ella, ya que le otorga la posibilidad de ser percibida; sin la luz y sin el objeto, el color no tiene existencia #[strong (Gianella, 2013).]
        p.mt-4 Una buena combinación de colores de los productos, de la sala de ventas y del mobiliario llama la atención y es suficiente para atraer la mirada del cliente, pues también el color produce sensaciones que pueden influir en el comportamiento de compra de los clientes #[strong (Escrivá, 2005).]
        p.mt-4 En la teoría de la pigmentación los colores se encuentran distribuidos en el círculo cromático, que está constituido por el conjunto de todos los colores agrupados ordenadamente en:
        ul.lista-ul.mt-5
          li.mb-0 
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Primarios: conocidos también como colores principales o generativos; se denominan así porque no están compuestos por ninguna mezcla y son el amarillo, el azul y el rojo.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Secundarios: se obtienen mezclando los colores primarios, así, por ejemplo, el naranja se obtiene mezclando el rojo y el amarillo, el verde se obtiene de la combinación del azul y amarillo y el violeta de la unión del rojo y el azul.
          li.mb-0.mt-2
            .row
              .col-1.text-align-right.p-0
                i.fas.fa-angle-right
              .col-11
                p Colores terciarios y sucesivos: con la combinación de los colores secundarios. 
      .col-5.d-none.d-lg-block 
        figure
          img(src="@/assets/template/tema-1-55.svg", alt="Texto que describa la imagen")
    p.mt-5 #[strong Escrivá (2005)] explica dos características importantes que hay que tener en cuenta en el estudio del color:
    .row.mt-5
      .col-12.col-lg-8.align-self-center
        p #[strong Armonía cromática:] los colores llaman mucho la atención cuando se combinan y para ello se suele recurrir a lo que se denomina armonía cromática, que se consigue cuando empleamos dos colores y uno de ellos contiene al otro, por ejemplo, entre el naranja y el amarillo existe armonía cromática puesto que el color naranja está formado por el rojo y el amarillo y, por tanto, ambos tienen en común el amarillo.
        p.mt-4 Otra forma de conseguir armonía cromática entre dos colores consiste en recurrir a un tercer color, cuya función es neutralizar las posibles diferencias que puedan existir entre ambos, por ejemplo, el rojo y el amarillo no combinan armoniosamente; pero si introducimos el naranja que contiene una mezcla de rojo y amarillo, se neutraliza la disparidad existente entre ambos, y se crea un conjunto armónico.
      .col-3.offset-1.d-none.d-lg-block.align-self-center
        figure
          img(src="@/assets/template/tema-1-56.svg", alt="Texto que describa la imagen")
    .row.mt-5
      .col-12.col-lg-8
        p #[strong Contraste:] Otra combinación atractiva puede ser el contraste entre dos o más colores, es decir, cuando al colocarlos juntos se observa una gran diferencia de intensidad, por ejemplo, el amarillo y el violeta contrastan al combinarlos, pues el amarillo resulta muy luminoso a la vista y el violeta mucho menos.
      .col-3.offset-1.d-none.d-lg-block.align-self-center
        figure
          img(src="@/assets/template/tema-1-57.svg", alt="Texto que describa la imagen")
    p.mt-5 #[strong Prieto (2018)] describe en la siguiente tabla el significado de los colores.
    .row.mt-5
      .col-12
        figure
          img(src="@/assets/template/tema-1-76.png", alt="Texto que describa la imagen").w-100
    .titulo-segundo.mt-5
      #t_1_11.h4 1.11  Comunicación comercial. Recursos de apoyo.
    .row.mt-5
      .col-12.col-lg-7
        p La comunicación comercial se realiza a través de eventos que son acontecimientos o actividades especiales de la compañía, en la que el mercado meta se hace presente a través de convenciones, jornadas de ventas, eventos promocionales masivos, conciertos, fiestas, etc., y donde se despliega toda una labor de venta o por lo menos se elabora un listado de referidos para posterior visita o entrevista. Estas actividades, y muchas otras, sirven para informar que hay un producto o servicio en el mercado, indicar para qué sirve, la manera de usarlo, sus beneficios por comprarlo y usarlo, dónde comprarlo y las facilidades para adquirirlo #[strong (Prieto, 2018).]
        p.mt-4 Para #[strong Prieto (2018)] los tipos de eventos de merchandising se clasifican de la siguiente manera:
      .col-5.d-none.d-lg-block.align-self-center
        figure
          img(src="@/assets/template/tema-1-61.png", alt="Texto que describa la imagen").w-75 
    AcordionA.mt-5(tipo="a" clase-tarjeta="tarjeta tarjeta--gris")
      .row(titulo="Eventos permanentes: ")
        .col-4.d-none.d-md-block.px-5
          figure
            img(src="@/assets/template/tema-1-62.png", alt="Texto que describa la imagen")
        .col-md-8
          p Son aquellos eventos de merchandising en los que el surtido se presenta de manera continua e indefinida, es decir, son constantes durante todo el año y se encuentran siempre dentro del punto de venta; se realizan para productos que no tienen una gran estacionalidad y que no están en promoción. Los productos se presentan, por lo general, en góndolas, murales y mostradores, y en algunas ocasiones en sitios especiales, islas o montoneras, dependiendo del tipo de establecimiento, producto y estrategia empresarial.

      div(titulo="Eventos de temporada: ")
        .row(titulo="Eventos de temporada: ")
          .col-4.d-none.d-md-block.px-5
            figure
              img(src="@/assets/template/tema-1-63.png", alt="Texto que describa la imagen")
          .col-md-8
            p Son aquellos eventos de merchandising en los que el surtido se expone por un tiempo definido, es decir, durante algunos períodos del año y se encuentran en temporadas especiales en el punto de venta. Los productos que se manejan en este tipo de eventos son aquellos que tienen una elevada estacionalidad y su exhibición debe ser atractiva y de gran impacto para el comprador.
      div(titulo="Eventos promocionales: ")
        .row(titulo="Eventos promocionales: ")
          .col-4.d-none.d-md-block.px-5
            figure
              img(src="@/assets/template/tema-1-64.png", alt="Texto que describa la imagen")
          .col-md-8
            p Son aquellos eventos de merchandising en los que el surtido se expone por un tiempo limitado, es decir, solo durante algunos períodos del año y que se encuentran en formas y momentos cortos en el punto de venta. Su propósito es atraer nuevos consumidores, mayor rentabilidad, equilibrar las temporadas, bajar existencias, realizar el lanzamiento de un producto, vender en cercanía a la fecha de vencimiento, realizar el cambio de referencias o de temporada y responder a la competencia del mercado. Se suelen utilizar obsequios o regalos en este tipo de eventos como: llaveros, gorras, calendarios, camisetas y muestras a menor escala de los productos promocionados, al buscar no solamente aumentar las ventas actuales, sino transformar a un nuevo cliente en el más fiel de los consumidores y, que la marca esté en contacto con el público.
    .h6.mt-5 Recursos de apoyo
    figure.mt-4
      img(src="@/assets/template/tema-1-65.png", alt="Texto que describa la imagen")  
    p.mt-5  En el mundo de la publicidad, el diseño industrial, el diseño gráfico y el diseño multimedia existe una gran diversidad de productos que ayudan a dar a conocer los atributos de otros productos, sea por medio de la seducción gráfica, lingüística, formal, en fin, hacen que los sentidos de los usuarios se estimulen a tal grado que influyan en la decisión de compra. Los productos que cumplen estos objetivos son conocidos como material publicitario o material P.O.P #[strong (Yate, 2012).]
    .h6.mt-5 Material P.O.P.: publicidad en el punto de venta
    figure.mt-4
      img(src="@/assets/template/tema-1-66.png", alt="Texto que describa la imagen")  
    p.mt-5 Lo que se denomina material P.O.P. son todos aquellos elementos usados en el point of purchase (punto de compra), como factores publicitarios empujadores que incitan a la adquisición de los productos exhibidos en el local, por algo las empresas le destinan entre el 6 y el 10% de su presupuesto de mercadeo y publicidad. Este material, regularmente lo componen afiches, audiovisuales, habladores, cenefas, móviles, colgantes, mesones demostradores, estanterías de demostración, banners, carteles, exhibidores electrónicos, mástiles, indicadores de precios, señales especiales, extensibles de estantería, calcomanías, islas, pilas, cabeceras de góndola y degustaciones; los cuales deben ser colocados y gestionados muy cerca de los productos para optimizar su papel. Son llamados los “vendedores silenciosos” porque informan, presentan y en ocasiones cierran negocios, pues inciden en el 65% de las compras impulsivas y en el 20% de las premeditadas #[strong (Prieto, 2018).]
    p.mt-4 Cuando el material P.O.P. es de naturaleza promocional, debe indicarse claramente en los planogramas los sitios indicados para su uso, así como el tipo de material permitido, dado que su fabricación será con materiales más perecederos como cartones o papeles que solo cumplen su función por un tiempo determinado, como soporte a técnicas promocionales, eventos y celebraciones #[strong (Martínez, 2018).]
    p.mt-4 El material P.O.P. debe transmitir el tema de campaña como soporte publicitario, convirtiéndose en interlocutor entre la empresa y su producto con el consumidor, al cumplir funciones de atracción y correlacionar la información emitida por otros medios con la que se encuentra en el punto de venta, o mínimo con la orientación e información en caso de que no se tuviese otro medio de comunicación diferente en uso #[strong (Martínez, 2018).]
    p.mt-4 #[strong Yate (2012)] explica algunos materiales P.O.P. utilizados en el punto de venta. 
    .row.mt-5
      .col-11.mx-5.p-4.bg-amarillo-claro.borde-izq-amarillo
        .row
          .col-4.d-none.d-md-block 
            figure.mt-4
              img(src="@/assets/template/tema-1-67.png", alt="Texto que describa la imagen")
          .col-12.col-md-8
            .h6 Toma uno:
            p.mt-4 Objeto o producto en el cual se ponen elementos publicitarios como son el flayer, el brochure y el sticker; con el fin de presentarlos, mostrarlos o exponerlos al público o usuario, para que los tomen o los cojan en forma de autoservicio. La acción de asir los elementos publicitarios se hace por unidad, de allí viene su nombre.
    .row.mt-3
      .col-11.mx-5.p-4.bg-amarillo-claro.borde-der-amarillo
        .row
          .col-4.d-none.d-md-block 
            figure.mt-4
              img(src="@/assets/template/tema-1-68.png", alt="Texto que describa la imagen")
          .col-12.col-md-8
            .h6 Rompetrafico: 
            p.mt-4 Objeto o producto que interrumpe, separa o quebranta el tránsito o circulación de los usuarios en un punto de venta. 
    .row.mt-5
      .col-11.mx-5.p-4.bg-amarillo-claro.borde-izq-amarillo
        .row
          .col-4.d-none.d-md-block 
            figure.mt-4
              img(src="@/assets/template/tema-1-69.png", alt="Texto que describa la imagen")
          .col-12.col-md-8
            .h6 Hablador: 
            p.mt-4 Objeto o producto que expresa por medio de su forma y grafismo publicitario, características de los productos y servicios publicitados.
    .row.mt-3
      .col-11.mx-5.p-4.bg-amarillo-claro.borde-der-amarillo
        .row
          .col-4.d-none.d-md-block 
            figure.mt-4
              img(src="@/assets/template/tema-1-70.png", alt="Texto que describa la imagen")
          .col-12.col-md-8
            .h6 Dummy: 
            p.mt-4 Objeto o producto que simula un producto de manera falsa o ficticia, como muñeco, títere o maniquí; que expresa por medio de su forma estética las características de los productos publicitados.
    .row.mt-3 
      .col-11.mx-5.p-0
        .cajon.color-acento-botones.p-4.mb-4.bg-amarillo-claro
          .row
            .col-12.col-md-8
              .h6.mt-4 Material promocional: publicidad con productos promocionales
              p.mt-3 Al hablar de material promocional se hace referencia a la publicidad lograda por medio de productos predeterminados, de uso cotidiano, que promocionan un producto, un servicio o una marca empresarial, a través de sus componentes gráficos y publicitarios formales. Los productos promocionales pueden o no estar en el punto de venta y requieren de un impulsor, que los obsequia a usuarios de mercados: potencial, disponible, objetivo o penetrado. Algunos productos promocionales son: lápices, bolígrafos, cajas de fósforos, llaveros y calendarios, entre un sinnúmero de objetos o productos, que solo están limitados por el recurso monetario destinado y la imaginación #[strong (Yate, 2012).]
            .col-4.d-none.d-md-block.align-self-center              
              figure
                img(src="@/assets/template/tema-1-71.png", alt="Texto que describa la imagen")
    .row.mt-3 
      .col-11.mx-5.p-0
        .cajon.color-acento-botones.p-4.mb-4.bg-amarillo-claro
          .row
            .col-4.d-none.d-md-block.align-self-center              
              figure
                img(src="@/assets/template/tema-1-72.png", alt="Texto que describa la imagen")
            .col-12.col-md-8
              .h6.mt-4 Material exterior: publicidad exterior
              p.mt-3 La publicidad exterior es aquella que se posiciona y ubica en lugares públicos y privados, que se encuentran fuera de los puntos de venta, que se dirige a los transeúntes. La publicidad exterior está conformada por carteles y vallas publicitarias, y todas las variantes de estos dos medios; es normal su ubicación o instalación en lugares públicos o donde se desarrollan espectáculos, eventos culturales, encuentros deportivos y azoteas de edificios, entre otros; se utilizan en la vía pública como vallas y carteles, en el transporte público y en lugares cerrados como eventos; los principales ejemplos son las vallas publicitarias, que son soportes sobre los cuales se fijan carteles publicitarios de gran formato y, los posters que son carteles, afiches, anuncios o avisos publicitarios que se fijan en un sitio público #[strong (Yate, 2012).]
    .row.mt-3 
      .col-11.mx-5.p-0
        .cajon.color-acento-botones.p-4.mb-4.bg-amarillo-claro
          .row
            .col-12.col-md-8
              .h6.mt-4 Material Web: publicidad en multimedia y Web
              p.mt-3 El material Web hace referencia a la publicidad en formato multimedia que se aplica en los sitios Web, en la Internet; para llevar a cabo las transacciones se involucra el dinero virtual. La publicidad Web: banner y pop up se insertan en la Web, weblog y blog, pueden contener textos, links o enlaces, logos, anuncios, audios, videos y animaciones. Su finalidad es informar, estimular y dar a conocer un producto o servicio al usuario que está en línea, en Internet #[strong (Yate, 2012).]
            .col-4.d-none.d-md-block.align-self-center              
              figure
                img(src="@/assets/template/tema-1-73.png", alt="Texto que describa la imagen")
    .titulo-segundo.mt-5
      #t_1_12.h4 1.12  Software de gestión en el punto de venta
    figure.mt-5
      img(src="@/assets/template/tema-1-74.png", alt="Texto que describa la imagen")
    p.mt-5 Ofrece la capacidad de almacenar bases de datos estándares, optimizar la inversión en inventario y espacio, mejorar la rentabilidad de las cadenas de suministro, implementar soluciones completas en la gestión por categorías y compartir la información para mejorar la eficiencia del merchandising #[strong (Prieto, 2018).]
    .titulo-segundo.mt-5
      #t_1_13.h4 1.13  Plan de exhibición
    figure.mt-5
      img(src="@/assets/template/tema-1-75.png", alt="Texto que describa la imagen")
    p.mt-5 Para el plan de acción de exhibición es necesario tener en cuenta objetivos (ubicación, espacio, rentabilidad, etc.), argumentos de venta (frases motivadoras extraídas de la publicidad), conocimiento del producto beneficiado (marca, posicionamiento, composición, sabores, colores, empaques, tamaños), tipos de herramientas (exhibiciones adicionales, material P.O.P.), zonas geográficas, duración de los eventos (permanente, temporada, promocionales), identificación de los negocios (grandes superficies, autoservicios, tiendas tradicionales, etc.), localización de espacios, instrumentos de comunicación y promoción, tipo de exhibición, y evaluación y seguimiento #[strong (Prieto, 2018).] 
    p.mt-5 Para la elaboración de un plan de acción de distribución se deben tener en cuenta los siguientes aspectos:
    ul.lista-ul.mt-5
      li.mb-0 
        .row
          .col-1.text-align-right.p-0
            i.fas.fa-angle-right
          .col-11
            p Objetivos.
      li.mb-0.mt-2
        .row
          .col-1.text-align-right.p-0
            i.fas.fa-angle-right
          .col-11
            p Descripción del producto.
      li.mb-0.mt-2
        .row
          .col-1.text-align-right.p-0
            i.fas.fa-angle-right
          .col-11
            p Estrategias y tácticas.
      li.mb-0.mt-2
        .row
          .col-1.text-align-right.p-0
            i.fas.fa-angle-right
          .col-11
            p Recursos.
      li.mb-0.mt-2
        .row
          .col-1.text-align-right.p-0
            i.fas.fa-angle-right
          .col-11
            p Presupuesto.
      li.mb-0.mt-2
        .row
          .col-1.text-align-right.p-0
            i.fas.fa-angle-right
          .col-11
            p Cronograma.
      li.mb-0.mt-2
        .row
          .col-1.text-align-right.p-0
            i.fas.fa-angle-right
          .col-11
            p Evaluación y control.











</template>

<script>
export default {
  name: 'Tema1',
  components: {},
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass" scoped>
.lista-ul li
  display: block
.fa-brain:before
  content: url('../assets/componentes/icono.svg')
.fa-angle-right
  color: #97181A
.bloque-texto-b i
  color: #97181A !important
.tabla-b__header
  background-color: #97181A !important
.boton--b:hover
  background-color: #97181A !important
.tabs-b.color-acento-contenido .tabs-b__tab--active
  border-top: $color-primario !important
.tarjeta--azul
  background-color: rgba(124, 197, 255, 0.2) !important
.tarjeta--gris
  background-color: #E8E8E8 !important
.bg-primario
  background-color: $color-primario
.bg-white
  background-color: $white
.bg-gris
  background-color: #F6F6F6
.bg-rojo-claro
  background-color: #FDB4A4
.bg-amarillo-claro
  background-color: #FFFAE8
.borde-izq-amarillo
  border-left: solid 15px #FFD947
.borde-der-amarillo
  border-right: solid 15px #FFD947
.borde-gris
  border: 4px solid #F6F6F6
  border-radius: 18px
.bloque-texto-a.color-secundario
  background-color: #E8E8E8 !important
.bloque-texto-a.color-secundario:before
  background-color: #FFF5A2 !important
.bloque-texto-a.color-acento-contenido
  background-color: #E8E8E8 !important
.bloque-texto-a.color-acento-contenido:before
  background-color: #FDB4A4 !important
.text-align-center
  text-align: -webkit-center
.text-align-right
  text-align: -webkit-right
.justify-content-center
  justify-content: center
</style>
