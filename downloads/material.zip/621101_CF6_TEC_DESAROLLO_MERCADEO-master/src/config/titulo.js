module.exports = 'Plan de merchandising'
